const String fence_id = "geofence_app_id";
const double radius_geofence = 150;
const String geofence_port_name = "geofence_port";
